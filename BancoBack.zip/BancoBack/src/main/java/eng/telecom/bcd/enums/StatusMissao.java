package eng.telecom.bcd.enums;

public enum StatusMissao {
    Iniciada,
    EmMissao,
    Retornou,
    Finalizada,
    Cancelada;
}
