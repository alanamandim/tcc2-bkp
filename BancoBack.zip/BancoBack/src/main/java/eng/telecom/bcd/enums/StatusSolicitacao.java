package eng.telecom.bcd.enums;

public enum StatusSolicitacao {
    AguardandoAProvacao,
    Aprovada,
    Recusada,
    Cancelada;
}
