package eng.telecom.bcd.requests;

import lombok.Data;

@Data
public class RegistrodeMissaoRequest {
    Integer idInspecao;
    Integer idSolicitacao;
    Integer idViatura;

}
