package eng.telecom.bcd.enums;

public enum Tanque {
    Cheio,
    TresQuartos,
    MeioTanque,
    UmQuarto;
}
