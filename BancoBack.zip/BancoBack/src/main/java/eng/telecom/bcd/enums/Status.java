package eng.telecom.bcd.enums;

public enum Status {
    Disponivel,
    Reservada,
    EmMissao;
}
