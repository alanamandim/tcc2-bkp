package eng.telecom.bcd.requests;
import lombok.Data;

@Data
public class AprovadorReservaRequest {
    String status;
    Integer id;
}
